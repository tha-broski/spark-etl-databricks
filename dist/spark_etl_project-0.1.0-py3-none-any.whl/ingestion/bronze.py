import uuid
import logging

from ingestion.csv_reader import read_csv
from pyspark.sql import functions as f

logger = logging.getLogger(__name__)


def ingest_to_bronze(spark, source_path, schema, bronze_table):
    logger.info("Bronze ingestion started")
    try:
        # ingestion/csv_reader.py -> reads source CSV using provided schema
        df = read_csv(spark, source_path, schema)

        # Generate unique batch_id for current snapshot | later used in main.py to process only current batch
        batch_id = str(uuid.uuid4())
        logger.info("batch_id=%s", batch_id)

        # Add technical metadata to raw data
        df = df.withColumn("ingestion_timestamp", f.current_timestamp())
        df = df.withColumn(
            "source_file",
            f.col("_metadata.file_path"),
        )
        df = df.withColumn("batch_id", f.lit(batch_id))
        logger.info(
            "Bronze Ingestion | source=%s | target=%s", source_path, bronze_table
        )

        # Append only -> keeps historical data
        df.write.format("delta").mode("append").saveAsTable(bronze_table)
        logger.info("Bronze data saved successfully")

        # Return batch_id to main.py so it can process only new snapshot
        return batch_id
    except Exception:
        # Raise the error if ingestion fails to stop the pipeline
        logger.exception("Bronze ingestion failed")
        raise
